using System.ComponentModel.DataAnnotations;

namespace InventoryManagementADONET.Models;

public class InventoryItem
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Item Name is required.")]
    [StringLength(100, ErrorMessage = "Item Name cannot exceed 100 characters.")]
    [Display(Name = "Item Name")]
    public string ItemName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Category is required.")]
    [StringLength(50)]
    public string Category { get; set; } = string.Empty;

    [Required(ErrorMessage = "Quantity is required.")]
    [Range(0, 100000, ErrorMessage = "Quantity must be a positive integer.")]
    public int Quantity { get; set; }

    [Required(ErrorMessage = "Unit Price is required.")]
    [Range(0.01, 1000000.00, ErrorMessage = "Unit Price must be greater than zero.")]
    [Display(Name = "Unit Price (INR)")]
    public decimal UnitPrice { get; set; }

    [Display(Name = "Stock Valuation")]
    public decimal TotalValue => Quantity * UnitPrice;

    [Display(Name = "Date Added")]
    public DateTime CreatedDate { get; set; } = DateTime.Now;
}
