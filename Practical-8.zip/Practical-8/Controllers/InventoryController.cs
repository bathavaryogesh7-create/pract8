using Microsoft.AspNetCore.Mvc;
using InventoryManagementADONET.Data;
using InventoryManagementADONET.Models;

namespace InventoryManagementADONET.Controllers;

public class InventoryController : Controller
{
    private readonly InventoryDAL _dal;

    public InventoryController(IConfiguration configuration)
    {
        var connStr = configuration.GetConnectionString("DefaultConnection")
                      ?? "Server=.;Database=InventoryDb;Trusted_Connection=True;TrustServerCertificate=True;";
        _dal = new InventoryDAL(connStr);
    }

    public IActionResult Index()
    {
        var items = _dal.GetAllItems();
        return View(items);
    }

    [HttpGet]
    public IActionResult Create()
    {
        return View(new InventoryItem());
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Create(InventoryItem item)
    {
        if (!ModelState.IsValid) return View(item);

        item.CreatedDate = DateTime.Now;
        if (_dal.InsertItem(item))
        {
            TempData["SuccessMessage"] = $"Item '{item.ItemName}' added successfully.";
            return RedirectToAction(nameof(Index));
        }

        ModelState.AddModelError("", "Database error occurred during insertion.");
        return View(item);
    }

    [HttpGet]
    public IActionResult Edit(int id)
    {
        var item = _dal.GetItemById(id);
        return item == null ? NotFound() : View(item);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Edit(int id, InventoryItem item)
    {
        if (id != item.Id) return BadRequest();
        if (!ModelState.IsValid) return View(item);

        if (_dal.UpdateItem(item))
        {
            TempData["SuccessMessage"] = $"Item '{item.ItemName}' updated successfully.";
            return RedirectToAction(nameof(Index));
        }

        ModelState.AddModelError("", "Database error occurred during update.");
        return View(item);
    }

    [HttpGet]
    public IActionResult Delete(int id)
    {
        var item = _dal.GetItemById(id);
        return item == null ? NotFound() : View(item);
    }

    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public IActionResult DeleteConfirmed(int id)
    {
        var item = _dal.GetItemById(id);
        string name = item?.ItemName ?? "Item";

        if (_dal.DeleteItem(id))
        {
            TempData["SuccessMessage"] = $"Item '{name}' deleted from inventory.";
        }
        return RedirectToAction(nameof(Index));
    }
}
