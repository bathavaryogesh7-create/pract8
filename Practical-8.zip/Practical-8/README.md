# Practical 8 - Inventory Management using ADO.NET (CRUD)

ASP.NET Core MVC (.NET 8) + Microsoft.Data.SqlClient. Pure ADO.NET (SqlConnection / SqlCommand / SqlDataReader), parameterized queries.

## Run
1. Open `Database/InventoryDb.sql` in SSMS (or Azure Data Studio) and execute it. This creates `InventoryDb` and seeds 5 rows.
2. Check `ConnectionStrings:DefaultConnection` in `appsettings.json` (default: local SQL Server, Windows auth).
   For SQL Express use `Server=.\\SQLEXPRESS;...`; for LocalDB use `Server=(localdb)\\MSSQLLocalDB;...`.
3. In this folder run:

       dotnet restore
       dotnet run

4. Open https://localhost:5001/Inventory  (if the port differs, use the one printed in the console).

Pages: /Inventory, /Inventory/Create, /Inventory/Edit/1, /Inventory/Delete/2

To target .NET 9, change `<TargetFramework>` to `net9.0`.
