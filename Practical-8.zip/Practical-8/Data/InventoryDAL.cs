using System.Data;
using Microsoft.Data.SqlClient;
using InventoryManagementADONET.Models;

namespace InventoryManagementADONET.Data;

public class InventoryDAL
{
    private readonly string _connectionString;

    public InventoryDAL(string connectionString)
    {
        _connectionString = connectionString;
    }

    private static InventoryItem Map(SqlDataReader reader) => new InventoryItem
    {
        Id = reader.GetInt32(0),
        ItemName = reader.GetString(1),
        Category = reader.GetString(2),
        Quantity = reader.GetInt32(3),
        UnitPrice = reader.GetDecimal(4),
        CreatedDate = reader.IsDBNull(5) ? DateTime.Now : reader.GetDateTime(5)
    };

    // SELECT ALL (READ)
    public List<InventoryItem> GetAllItems()
    {
        var items = new List<InventoryItem>();
        using var connection = new SqlConnection(_connectionString);
        using var command = new SqlCommand(
            "SELECT Id, ItemName, Category, Quantity, UnitPrice, CreatedDate FROM InventoryItems ORDER BY Id DESC",
            connection);

        connection.Open();
        using var reader = command.ExecuteReader();
        while (reader.Read())
        {
            items.Add(Map(reader));
        }
        return items;
    }

    // SELECT BY ID (READ SINGLE)
    public InventoryItem? GetItemById(int id)
    {
        using var connection = new SqlConnection(_connectionString);
        using var command = new SqlCommand(
            "SELECT Id, ItemName, Category, Quantity, UnitPrice, CreatedDate FROM InventoryItems WHERE Id = @Id",
            connection);
        command.Parameters.Add(new SqlParameter("@Id", SqlDbType.Int) { Value = id });

        connection.Open();
        using var reader = command.ExecuteReader();
        return reader.Read() ? Map(reader) : null;
    }

    // INSERT (CREATE)
    public bool InsertItem(InventoryItem item)
    {
        using var connection = new SqlConnection(_connectionString);
        using var command = new SqlCommand(
            "INSERT INTO InventoryItems (ItemName, Category, Quantity, UnitPrice, CreatedDate) " +
            "VALUES (@ItemName, @Category, @Quantity, @UnitPrice, @CreatedDate)",
            connection);

        command.Parameters.Add(new SqlParameter("@ItemName", SqlDbType.NVarChar, 100) { Value = item.ItemName });
        command.Parameters.Add(new SqlParameter("@Category", SqlDbType.NVarChar, 50) { Value = item.Category });
        command.Parameters.Add(new SqlParameter("@Quantity", SqlDbType.Int) { Value = item.Quantity });
        command.Parameters.Add(new SqlParameter("@UnitPrice", SqlDbType.Decimal) { Precision = 10, Scale = 2, Value = item.UnitPrice });
        command.Parameters.Add(new SqlParameter("@CreatedDate", SqlDbType.DateTime) { Value = item.CreatedDate });

        connection.Open();
        return command.ExecuteNonQuery() > 0;
    }

    // UPDATE
    public bool UpdateItem(InventoryItem item)
    {
        using var connection = new SqlConnection(_connectionString);
        using var command = new SqlCommand(
            "UPDATE InventoryItems SET ItemName = @ItemName, Category = @Category, " +
            "Quantity = @Quantity, UnitPrice = @UnitPrice WHERE Id = @Id",
            connection);

        command.Parameters.Add(new SqlParameter("@Id", SqlDbType.Int) { Value = item.Id });
        command.Parameters.Add(new SqlParameter("@ItemName", SqlDbType.NVarChar, 100) { Value = item.ItemName });
        command.Parameters.Add(new SqlParameter("@Category", SqlDbType.NVarChar, 50) { Value = item.Category });
        command.Parameters.Add(new SqlParameter("@Quantity", SqlDbType.Int) { Value = item.Quantity });
        command.Parameters.Add(new SqlParameter("@UnitPrice", SqlDbType.Decimal) { Precision = 10, Scale = 2, Value = item.UnitPrice });

        connection.Open();
        return command.ExecuteNonQuery() > 0;
    }

    // DELETE
    public bool DeleteItem(int id)
    {
        using var connection = new SqlConnection(_connectionString);
        using var command = new SqlCommand("DELETE FROM InventoryItems WHERE Id = @Id", connection);
        command.Parameters.Add(new SqlParameter("@Id", SqlDbType.Int) { Value = id });

        connection.Open();
        return command.ExecuteNonQuery() > 0;
    }
}
