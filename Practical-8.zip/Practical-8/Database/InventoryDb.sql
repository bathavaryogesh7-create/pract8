-- Database Schema and Table Creation Script
CREATE DATABASE InventoryDb;
GO

USE InventoryDb;
GO

CREATE TABLE InventoryItems (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    ItemName NVARCHAR(100) NOT NULL,
    Category NVARCHAR(50) NOT NULL,
    Quantity INT NOT NULL,
    UnitPrice DECIMAL(10,2) NOT NULL,
    CreatedDate DATETIME DEFAULT GETDATE()
);
GO

-- Seed Initial Inventory Records
INSERT INTO InventoryItems (ItemName, Category, Quantity, UnitPrice, CreatedDate)
VALUES
('Dell Latitude 3420 Laptop', 'Computers', 25, 52000.00, GETDATE()),
('Logitech MX Master 3S Mouse', 'Accessories', 60, 7999.00, GETDATE()),
('Mechanical Gaming Keyboard', 'Accessories', 45, 3499.00, GETDATE()),
('HP LaserJet Pro Printer', 'Peripherals', 12, 18500.00, GETDATE()),
('Samsung 27-inch 4K Monitor', 'Displays', 30, 24999.00, GETDATE());
GO
